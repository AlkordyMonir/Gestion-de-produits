\c magasin_db

INSERT INTO Produit (  nom , descrption ,  date_create , date_update ,stock,pCode,rCode ) VALUES ('nom1', 'descrption1',  '2018-09-24','2018-09-24',1,111,222);
INSERT INTO Produit (  nom , descrption ,  date_create , date_update ,stock ,pCode,rCode ) VALUES ('nom2', 'descrption1',  '2018-09-24','2018-09-24',2,112,221);
INSERT INTO Produit (  nom , descrption ,  date_create , date_update ,stock ,pCode,rCode ) VALUES ('nom3', 'descrption1',  '2018-09-24','2018-09-24',3,555,555);
INSERT INTO Produit (  nom , descrption ,  date_create , date_update ,stock ,pCode,rCode ) VALUES ('nom4', 'descrption1',  '2018-09-24','2018-09-24',4,123,647);
INSERT INTO Produit (  nom , descrption ,  date_create , date_update ,stock ,pCode,rCode ) VALUES ('nom5', 'descrption1',  '2018-09-24','2018-09-24',5,142,856);
INSERT INTO Produit (  nom , descrption ,  date_create , date_update ,stock ,pCode,rCode  ) VALUES ('nom6', 'descrption1',  '2018-09-24','2018-09-24',6,414,512);
INSERT INTO Produit (  nom , descrption ,  date_create , date_update ,stock ,pCode,rCode  ) VALUES ('nom7', 'descrption1',  '2018-09-24','2018-09-24',7,114,854);
INSERT INTO Produit (  nom , descrption ,  date_create , date_update ,stock ,pCode,rCode ) VALUES ('nom8', 'descrption1',  '2018-09-24','2018-09-24',8,318,321);
INSERT INTO Produit (  nom , descrption ,  date_create , date_update ,stock ,pCode,rCode ) VALUES ('nom9', 'descrption1',  '2018-09-24','2018-09-24',9,158,327);
INSERT INTO Produit (  nom , descrption ,  date_create , date_update ,stock ,pCode,rCode ) VALUES ('nom10', 'descrption1',  '2018-09-24','2018-09-24',111,666,654);
INSERT INTO Produit (  nom , descrption ,  date_create , date_update ,stock ,pCode,rCode ) VALUES ('nom11', 'descrption1',  '2018-09-24','2018-09-24',88,658,544);



INSERT INTO Categorie(nom , description, date_create, date_update) VALUES ('Categorie1', 'descrptionCategorie1','2018-09-24','2018-09-24');
INSERT INTO Categorie(nom , description, date_create, date_update) VALUES ('Categorie2', 'descrptionCategorie2','2018-09-24','2018-09-24');
INSERT INTO Categorie(nom , description, date_create, date_update) VALUES ('Categorie3', 'descrptionCategorie3','2018-09-24','2018-09-24');
INSERT INTO Categorie(nom , description, date_create, date_update) VALUES ('Categorie4', 'descrptionCategorie4','2018-09-24','2018-09-24');




INSERT INTO Image ( URL ,  date_create , date_update ) VALUES ('http/:qsfdfqfqdfqf','2018-09-24','2018-09-24');
INSERT INTO Image ( URL ,  date_create , date_update ) VALUES ('http/:qsfdfqfqdfqf','2018-09-24','2018-09-24');
INSERT INTO Image ( URL ,  date_create , date_update ) VALUES ('http/:qsfdfqfqdfqf','2018-09-24','2018-09-24');





INSERT INTO etat ( valeur ) VALUES (1);
INSERT INTO etat ( valeur ) VALUES (2);
INSERT INTO etat ( valeur ) VALUES (3);
INSERT INTO etat ( valeur ) VALUES (4);
INSERT INTO etat ( valeur ) VALUES (5);




INSERT INTO Asso_1( Id_Produit , Id_Image )VALUES (1,1);
INSERT INTO Asso_1( Id_Produit ,Id_Image )VALUES (2,2);
INSERT INTO Asso_1( Id_Produit ,Id_Image )VALUES (3,3);
INSERT INTO Asso_1( Id_Produit ,Id_Image )VALUES (4,2);
INSERT INTO Asso_1( Id_Produit ,Id_Image )VALUES (1,1);

INSERT INTO Asso_2(Id_Produit ,Id_Categorie )VALUES (1,1);
INSERT INTO Asso_2(Id_Produit ,Id_Categorie )VALUES (2,2);
INSERT INTO Asso_2(Id_Produit ,Id_Categorie )VALUES (3,3);
INSERT INTO Asso_2(Id_Produit ,Id_Categorie )VALUES (4,4);
INSERT INTO Asso_2(Id_Produit ,Id_Categorie )VALUES (5,1);
INSERT INTO Asso_2(Id_Produit , Id_Categorie )VALUES (6,1);
INSERT INTO Asso_2(Id_Produit ,Id_Categorie )VALUES (7,2);
INSERT INTO Asso_2(Id_Produit ,Id_Categorie )VALUES (1,2);
INSERT INTO Asso_2(Id_Produit ,Id_Categorie )VALUES (1,3);
INSERT INTO Asso_2(Id_Produit ,Id_Categorie )VALUES (1,4);






INSERT INTO Asso_3(Id_Produit ,Id_etat )VALUES (1,1);
INSERT INTO Asso_3(Id_Produit ,Id_etat )VALUES (2,2);
INSERT INTO Asso_3(Id_Produit ,Id_etat )VALUES (3,3);
INSERT INTO Asso_3(Id_Produit ,Id_etat )VALUES (4,3);
INSERT INTO Asso_3(Id_Produit ,Id_etat )VALUES (5,4);
INSERT INTO Asso_3(Id_Produit ,Id_etat )VALUES (6,5);
INSERT INTO Asso_3(Id_Produit ,Id_etat )VALUES (7,4);
INSERT INTO Asso_3(Id_Produit ,Id_etat )VALUES (8,4);





















