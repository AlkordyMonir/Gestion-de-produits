/*
Creating database
Auteur Monir
*/
CREATE DATABASE crf_db

encoding= 'UTF8';

/*
Create schema
*/

--CREATE SCHEMA crf_db.magasin;
/*
Create table
*/
\c crf_db;
CREATE TABLE Produit (
                Id_Produit INT GENERATED ALWAYS AS IDENTITY ,
                nom varchar(20) not null,
                descrption varchar(255) not null,
		stock INT not null,
                pCode INT not null,
                rCode INT not null,
                date_create date,
                date_update date,
    	  PRIMARY KEY(id_produit),
	  UNIQUE(pCode),
	  UNIQUE(rCode)

);

CREATE TABLE Image(
   Id_Image INT GENERATED ALWAYS AS IDENTITY,
   URL VARCHAR(50), 
   date_create DATE, 
   date_update DATE,
   PRIMARY KEY(Id_Image)
);   

CREATE TABLE Categorie(
   Id_Categorie INT GENERATED ALWAYS AS IDENTITY,
   nom VARCHAR(50),
   description VARCHAR(50),
   date_create DATE,
   date_update DATE,
   PRIMARY KEY(Id_Categorie)
);   

CREATE TABLE etat(
   Id_etat INT GENERATED ALWAYS AS IDENTITY,
   valeur INT NOT NULL,
   PRIMARY KEY(Id_etat)
);   

CREATE TABLE Asso_1(
   Id_Produit INT,
   Id_Image INT,
   PRIMARY KEY(Id_Produit, Id_Image),
   FOREIGN KEY(Id_Produit) REFERENCES Produit(Id_Produit),
   FOREIGN KEY(Id_Image) REFERENCES Image(Id_Image)
);   

CREATE TABLE Asso_2(
   Id_Produit INT,
   Id_Categorie INT,
   PRIMARY KEY(Id_Produit, Id_Categorie),
   FOREIGN KEY(Id_Produit) REFERENCES Produit(Id_Produit),
   FOREIGN KEY(Id_Categorie) REFERENCES Categorie(Id_Categorie)
);   

CREATE TABLE Asso_3(
   Id_Produit INT,
   Id_etat INT,
   PRIMARY KEY(Id_Produit, Id_etat),
   FOREIGN KEY(Id_Produit) REFERENCES Produit(Id_Produit),
   FOREIGN KEY(Id_etat) REFERENCES etat(Id_etat)
);   



 